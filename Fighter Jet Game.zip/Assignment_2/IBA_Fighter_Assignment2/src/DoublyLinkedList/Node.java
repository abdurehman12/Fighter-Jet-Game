package DoublyLinkedList;

import Objects.Vehicle;

public class Node {
    public  Vehicle data; // object that will be stored
    public Node next, prev; // for previous and next node in our linked list
    Node( Vehicle a){ // Node constructor
        data=a;
        next=prev=null;
    }
}
