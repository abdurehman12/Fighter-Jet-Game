package DoublyLinkedList;

import Objects.Vehicle;

public class linkedList {
    public Node head;  //defines the head of the linked list
    public Node tail;  // for defining the tail of the linked list
    private int count; // counts the number of objects in the linked list
    public linkedList(){ // constructor of our linked list
        head=tail=null;
    }

    public void Add( Vehicle a){
        /* add a value to our linked list if it is the first value is assigned to the head*/

        count++;
        if(head==null){
            head=tail=new Node( a);
            head.prev=null;
            head.next=null;
        }
        else{
            Node temp=new Node(a);
            tail.next=temp;
            temp.prev=tail;
            tail=temp;
            tail.next=null;
        }
    }

    public int length(){ // returns the length or our linked list

        return count;
    }

    public Vehicle showAt(int n) {
        // returns the object stored at the nth value in our list; where n is provided by the user.
        Node temp=head;
        if(head!=null){
        {
            for (int i = 0; i < n; i++) {
                if(temp!=null && temp.next!=null)
                temp = temp.next;
            }
        }
        return temp.data;
    }
        return null;
    }

    public boolean isnull(){
        // confirms if the linked list is null or not
        return head == null;
    }


    public void dequeue(){
        /* removes the object who's Vehicle.alive is falls
        runs for the whole list.
         */

        Node temp=head;
        while (temp!=null)
        {
            if(!temp.data.isAlive()){
                Node dlt=temp;
                temp=temp.next;
                if(dlt.prev!=null){
                    dlt.prev.next=dlt.next;
                }
                else {
                    head=temp;
                }
                if(dlt.next!=null){
                    dlt.next.prev=dlt.prev;
                }
                else
                {
                    tail=dlt.prev;
                }
                dlt = null;
                count--;
            }
            else temp=temp.next;
        }

    }
}
