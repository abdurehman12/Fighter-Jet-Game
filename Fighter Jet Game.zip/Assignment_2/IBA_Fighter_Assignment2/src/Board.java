/*
all the Java API's used are imported here.
 */
import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JPanel;

import Objects.Player;
import Objects.Vehicle;
import Objects.bomber;
import Objects.bullet;
import DoublyLinkedList.linkedList;

public class Board extends JPanel implements ActionListener {
    private static final long serialVersionUID = 1L;

    private final int DELAY = 10; // defines after how much time every action performed is called.

    private Player player; // creates and instance of player
    private Enemy enemy1; //creates an instance of enemy
    private Enemy enemy2;
    private bullet bullet1; // creates an instance of bullet
    private bomber Bomber1; // creates an instance of bomber.
    String[] Player_path = {"src/Sprites/BF-109E/Type-1/Animation/1.png", "src/Sprites/BF-109E/Type-1/Animation/2.png", "src/Sprites/BF-109E/Type-1/Animation/3.png"};
    String[] enemy_path = {"src/Sprites/FighterSprite/1.png", "src/Sprites/FighterSprite/2.png", "src/Sprites/FighterSprite/3.png"};
    String[] Bomber_path = {"src/Sprites/B-17/Type-1/Animation/1.png", "src/Sprites/B-17/Type-1/Animation/2.png", "src/Sprites/B-17/Type-1/Animation/3.png"};
    private int w = 1024;  // used for defining the width of our screen
    private int h = 768;  // used for defining the height of our screen
    linkedList linkedList = new linkedList(); // used for storing our object
    private int count = 0;
    private Timer timer; // to start the real time timer

    public Board() {

        initBoard();
    }

    private void initBoard() //Initializes all the game objects
    {
        addKeyListener(new TAdapter());
        setBackground(Color.black);
        setFocusable(true);

        player = new Player(Player_path, w / 2, h * 3 / 4);  // creates a player player object
        enemy1 = new Enemy(enemy_path, (int) ((Math.random() * w)), 0); // randomly generates enemies
        linkedList.Add(enemy1); // adds the enemy in the linked list
        Bomber1 = new bomber(Bomber_path, (int) ((Math.random() * w)), 0); // randomly generates bomber
        linkedList.Add(Bomber1); //adds the bomber in the linked list
        setPreferredSize(new Dimension(w, h));  //Set the size of Window
        timer = new Timer(DELAY, this);  //Timer with 10 ms delay
        timer.start();
    }


    @Override
    public void paintComponent(Graphics g) //Draws all the components on screen
    {
        g.setColor(getBackground());        //get the background color
        g.clearRect(0, 0, w, h);    //clear the entire window
        Dimension size = getSize();  //get the current window size
        w = (int) size.getWidth();
        h = (int) size.getHeight();

        Graphics2D g2d = (Graphics2D) g;
        player.paintComponent(g2d);  //paint the player
        paint_list(g2d, linkedList); // paints all the components in the list
        Toolkit.getDefaultToolkit().sync();
    }


    public void actionPerformed(ActionEvent e) {
        player.move(); // used for moving the player when key pressed

        if (bullet1 != null) { // used for moving the bullet fired by the player
            bullet1.move();
        }
        if (count % 100 == 0) { // used for randomly creating enemy after a 100th count value
            enemy2 = new Enemy(enemy_path, (int) ((Math.random() * w)), 0);
            linkedList.Add(enemy2); // adds all the enemies to the list
        }

        step();
        /*
        used for restricting the player with in the bounds of the screen/
         */
        if (player.getX() < 130) {
            player.moveTo(130, player.getY());
        }
        if (player.getX() > w - 130)
            player.moveTo(w - 130, player.getY());
        if (player.getY() < 130) {
            player.moveTo(player.getX(), 130);
        }
        if (player.getY() > h - 130) {
            player.moveTo(player.getX(), h - 130);
        }
        /*
        used for randomly creating and adding to link list the bombers.
         */
        if (count % 500 == 0) {
            Bomber1 = new bomber(Bomber_path, (int) ((Math.random() * w)), 0);
            linkedList.Add(Bomber1);
        }


    }

    private void step() {
        repaint(); // calls paint function repeatedly
        count++; // increase counter
        {
            /*
            Used for deleting unwanted objects.
             */
            if (linkedList.head != null) {
                for (int i = 0; i < linkedList.length(); i++) {
                    if (linkedList.showAt(i) != null) {
                        Vehicle vehicle = linkedList.showAt(i);
                        vehicle.move();
                        if (vehicle instanceof Enemy || vehicle instanceof bomber) {
                            if (vehicle.getY() > h + 130) {
                                vehicle.setAlive(false);
                                Cleanup();
                            }
                        }
                        else if (vehicle instanceof bullet) {
                            if (vehicle.getY() < 0) {
                                vehicle.setAlive(false);
                                Cleanup();
                            }
                        }
                    }
                }
            }

        }

        check_collision(); // check if the bullet and enemy or bomber as intersected.
    }

    private void Cleanup() {
        linkedList.dequeue(); //clean the list from unwanted objects
    }


    private class TAdapter extends KeyAdapter {

        @Override
        public void keyReleased(KeyEvent e) {
            player.keyReleased(e);
        }

        @Override
        public void keyPressed(KeyEvent e) {
            player.keyPressed(e); // calls player key press when ever a key is press
            /*
            if the key is space, it calls the get fire bullet method of player
            which returns an object of bullet created
             */
            int key = e.getKeyCode();
            if (key == KeyEvent.VK_SPACE) {
                bullet1 = player.getFiredbullet();
                linkedList.Add(bullet1);
            }
        }
    }
     /*
     used for iteratively painting each object in the linked list
      */
    public void paint_list(Graphics2D a, linkedList list) {
        for (int i = 0; i < list.length(); i++) {
            if (list.showAt(i) != null) {
                Vehicle vehicle = list.showAt(i);
                vehicle.paintComponent(a);
            }
        }
    }
    /*
      checks if the bullet is near an enemy, it will dodge it.
      And checks if the bullet is collided with the enemy or bomber.
     */
    public void check_collision() {
        for (int i = 0; i < linkedList.length(); i++) {
            if (linkedList.showAt(i) != null) {
                Vehicle object = linkedList.showAt(i);
                if (object instanceof bullet) {
                    Rectangle r2 = object.getBounds();
                    for (int x= 0; x < linkedList.length(); x++) {
                        if (linkedList.showAt(x) != null) {
                            Vehicle object2 = linkedList.showAt(x);
                            if (object2 instanceof Enemy || object2 instanceof bomber) {
                                Rectangle r3 = object2.getBounds();
                                Rectangle r4 = new Rectangle((int)r3.getX(),(int)r3.getY(),(int)r3.getWidth(),(int)r3.getHeight());
                                r4.setLocation((int)r4.getX(),(int)r4.getY()+200);
                                if (r4.intersects(r2) && object2 instanceof Enemy)
                                {
                                    ((Enemy) object2).dodge_bullet((int)(r2.getX()));
                                }

                                if (r3.intersects(r2)) {
                                    object2.setAlive(false);
                                    object.setAlive(false);
                                    Cleanup();
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
