
import Objects.Vehicle;

public class Enemy extends Vehicle {
    public Enemy(String[] path, int x, int y) {
        super(path, x, y); //same as vehicle constructor
    }

    @Override
    public void move() {// used for continuously moving the enemy
     y+=2;
    }
    @Override
    public void Fire() {

    }
    public void dodge_bullet(int bullet_position){
        // used for dodging the bullet of our player
        /*
        from which ever side the bullet is coming from, enemy will move to the opposite side.
         */
        if(this.x>bullet_position){
             x+=5;
        }
        else {
            x-=5;
        }

    }
}
