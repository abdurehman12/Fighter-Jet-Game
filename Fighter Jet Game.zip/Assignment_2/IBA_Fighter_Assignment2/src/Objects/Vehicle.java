package Objects;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import javax.swing.ImageIcon;


public abstract class Vehicle 
{
	protected Image [] image=new Image[3]; // stores the array of images that will be iteratively show on the screen
	protected int x;
	protected int y;
	protected int w;
    protected int h;
	protected int dx, dy;
	protected boolean alive;
		/*
		stores the coordinate, dimensions and status of the vehicle
		 */
	protected long count = 1; //used for running the array of images
	
	public Vehicle(String [] path, int x, int y)
	{
		/*
		creates an object of vehicle through the image path and coordinates provided as
		parameters.
		*/
		this.x = x;
		this.y = y;
		for(int i=0;i< path.length;i++) {
			ImageIcon imageIcon = new ImageIcon(path[i]); // used for creating img.
			image[i] = imageIcon.getImage();
			w = image[i].getWidth(null);
			h = image[i].getHeight(null);
		}
		this.alive=true; //status of the object is set
	}

	
	public Rectangle getBounds() {
	    return new Rectangle(x-w/2, y-w/2, w, h); // returns the space covered by our vehicle on the screen
	}

	public void paintComponent(Graphics2D g)
	{
		/*
		used for showing our image graphically on the screen.
		 */
		int num = (int)(count%3);
		g.drawImage(image[num], x - image[num].getWidth(null)/2, y - image[num].getHeight(null)/2, null);
		g.setColor(new Color(255,0,0));
		g.drawRect(x-w/2, y-w/2, w, h); //Only to show image bounds, can be removed

		count++;
	}

	public void moveTo(int x, int y)
	{	/*
		sets the object to a specific location on our screen.
		*/
		this.x = x;
		this.y = y;
	}
	
	public abstract void move();
	public abstract void Fire();
	
	
	public int getX() {
		// returns the x coordinate of our object
        return x;
    }

    public int getY() {
		// returns the y coordinate of our object
        return y;
    }
    
    public int getWidth() {
        // returns the width of our object
        return w;
    }
    
    public int getHeight() {
		// returns the height of our object
		return h;
    }    

    public Image[] getImage() {
		// returns the image formed on the screen of our object
        return image;
    }

	public boolean isAlive() {
		// returns the status of our object
		return alive;
	}

	public void setAlive(boolean alive) {
		// sets the status of our object
		this.alive = alive;
	}
}
