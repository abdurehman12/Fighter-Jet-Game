package Objects;

public class bomber extends Vehicle{
    public bomber(String[] path, int x, int y) {
        super(path, x, y); // same as vehicle constructor.
    }
    @Override
    public void move() {
        // used for continuously moving the bomber.
        y+=2;
    }

    @Override
    public void Fire() {

    }
}
