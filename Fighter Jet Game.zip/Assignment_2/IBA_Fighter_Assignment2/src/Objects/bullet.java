package Objects;

public class bullet extends Vehicle{
    public bullet(String[] path, int x, int y) {
        super(path, x, y); // same as vehicle constructor.
    }


    @Override
    public void move() {
    y-=4; // used for moving the bullet in a straight path
    }

    @Override
    public void Fire() {
    }
}
