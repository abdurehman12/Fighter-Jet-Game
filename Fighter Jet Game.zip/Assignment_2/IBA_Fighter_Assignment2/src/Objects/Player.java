
package Objects;

import java.awt.event.KeyEvent;

public class Player extends Vehicle
{
    private bullet firedbullet; // used for assigning fire created of our player
    private final String[] bullet_path={"src/Sprites/PlayerFire/1.png", "src/Sprites/PlayerFire/2.png", "src/Sprites/PlayerFire/3.png"};
	public Player(String [] path, int x, int y)
	{
		super(path, x, y); // same as vehicle constructor
	}
	
	public void move()
	{
	    // moves the x and y coordinate to the value added.

		this.x += dx;
		this.y += dy;

	}

	
	public void keyPressed(KeyEvent e) 
	{
        /*
        when key is pressed, a value is assigned to dy or dx according to
        what key is pressed.
        if space is pressed method fire() is called.
         */
        int key = e.getKeyCode();

        if (key == KeyEvent.VK_LEFT) {
                dx = -4;
        }

        if (key == KeyEvent.VK_RIGHT) {
            dx = 4;
        }

        if (key == KeyEvent.VK_UP) {
            dy = -4;
        }

        if (key == KeyEvent.VK_DOWN) {
            dy = 4;
        }
        if (key == KeyEvent.VK_SPACE) {
            Fire();
        }
    }
	public void Fire()
	{
	    // creates an object of fire.
         firedbullet= new bullet(bullet_path,getX(),getY());
		
	}

    public void keyReleased(KeyEvent e) 
    {
        // as key is released nullifies the value assigned to dy or dx.
        int key = e.getKeyCode();

        if (key == KeyEvent.VK_LEFT) {
            dx = 0;
        }

        if (key == KeyEvent.VK_RIGHT) {
            dx = 0;
        }

        if (key == KeyEvent.VK_UP) {
            dy = 0;
        }

        if (key == KeyEvent.VK_DOWN) {
            dy = 0;
        }
    }

    public bullet getFiredbullet() {
        return firedbullet;
        // returns the object of bullet created in fire() method.
    }

}
